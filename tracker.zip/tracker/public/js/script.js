const socket = io();

// ========== SEND YOUR LIVE LOCATION ==========
if (navigator.geolocation) {
    navigator.geolocation.watchPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            socket.emit("send-location", { latitude, longitude });
        },
        (error) => console.error(error),
        {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0,
        }
    );
}

// ========== INITIALIZE MAP ==========
const map = L.map("map").setView([28.6139, 77.2090], 16);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "IMS",
}).addTo(map);

const markers = {};


// ========== ⭐ ADD YOUR CUSTOM LOCATION HERE ==========
/*
  Example: IMS Noida
  Latitude: 28.6296
  Longitude: 77.3793
*/

const imsLat = 28.6296;
const imsLng = 77.3793;


L.marker([imsLat, imsLng])
  .addTo(map)
  .bindPopup("IMS Noida");  
// ========== ⭐ LOCATION ADDED SUCCESSFULLY ==========


// ========== RECEIVE REAL-TIME LOCATIONS ==========
socket.on("receive-location", (data) => {
    const { id, latitude, longitude } = data;

    if (markers[id]) {
        markers[id].setLatLng([latitude, longitude]);
    } else {
        markers[id] = L.marker([latitude, longitude]).addTo(map);

        // Center map only when new user appears
        map.setView([latitude, longitude], 16);
    }
});


// ========== REMOVE USER WHEN DISCONNECTED ==========
socket.on("user-disconnected", (id) => {
    if (markers[id]) {
        map.removeLayer(markers[id]);
        delete markers[id];
    }
});
